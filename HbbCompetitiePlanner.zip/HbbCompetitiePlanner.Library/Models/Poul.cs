﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Poul : ObservableObject {

        public string Naam { get; set; }
        public List<Team> Teams { get; } = new List<Team>();
        public List<Speelronde> Speelrondes { get; } = new List<Speelronde>();

        public void CreateSpeelrondes() {
            // Source: https://stackoverflow.com/questions/1293058/round-robin-tournament-algorithm-in-c-sharp/1293174#1293174

            this.Speelrondes.Clear();

            var ListTeam = new List<Team>(Teams);
            if (ListTeam.Count % 2 != 0) {
                ListTeam.Add(null);
            }
            var numTeams = ListTeam.Count;

            int numDays = (numTeams - 1);
            int halfSize = numTeams / 2;

            List<Team> teams = new List<Team>();

            teams.AddRange(ListTeam.Skip(halfSize).Take(halfSize));
            teams.AddRange(ListTeam.Skip(1).Take(halfSize - 1).ToArray().Reverse());

            int teamsSize = teams.Count;

            for (int day = 0; day < numDays; day++) {

                var ronde = new Speelronde() {
                    Nummer = day + 1,
                };
                this.Speelrondes.Add(ronde);
                Console.WriteLine("Day {0}", (day + 1));

                int teamIdx = day % teamsSize;
                ronde.Wedstrijden.Add(new Wedstrijd(teams[teamIdx], ListTeam[0], this));

                for (int idx = 1; idx < halfSize; idx++) {
                    int firstTeam = (day + idx) % teamsSize;
                    int secondTeam = (day + teamsSize - idx) % teamsSize;
                    if (teams[firstTeam] is object && teams[secondTeam] is object) {
                        ronde.Wedstrijden.Add(new Wedstrijd(teams[firstTeam], ListTeam[secondTeam], this));
                    }
                }
            }

        }

    }
}
