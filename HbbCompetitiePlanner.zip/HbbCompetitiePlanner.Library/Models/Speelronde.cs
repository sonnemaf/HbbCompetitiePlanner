﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Speelronde : ObservableObject {

        public int Nummer { get; set; }

        public List<Wedstrijd> Wedstrijden { get; } = new List<Wedstrijd>();

    }
}
