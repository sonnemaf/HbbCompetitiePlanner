﻿using HbbCompetitiePlanner.Library.Models;
using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;

namespace HbbCompetitiePlanner.Library.ViewModels {

    public class MainViewModel {

        public static MainViewModel Current { get; } = new MainViewModel();

        public ICommand StartCommand { get; }

        public Competitie Competitie { get; private set; }

        private MainViewModel() {
            this.StartCommand = new RelayCommand(OnStart);


        }

        private void OnStart() {
            this.Competitie = new Competitie {
                Naam = "2019-2020"
            };

            // Speelavonden
            for (int i = 0; i < 20; i++) {
                // Woensdag
                this.Competitie.Speelavonden.Add(new Speelavond {
                    Datum = new DateTime(2019, 9, 16).AddDays(i * 7),
                    AantalBanen = 11
                });

                // Donderdag
                this.Competitie.Speelavonden.Add(new Speelavond {
                    Datum = new DateTime(2019, 9, 17).AddDays(i * 7),
                    AantalBanen = 11
                });
            }

            // Pouls
            for (int i = 1; i < 5; i++) {
                var p = new Poul {
                    Naam = $"Klasse {i}",
                };

                for (int t = 1; t <= (i < 3 ? 8 : 7); t++) {
                    p.Teams.Add(new Team() {
                        Naam = $"Team {t} - {p.Naam}"
                    });
                }

                p.CreateSpeelrondes();

                this.Competitie.Pouls.Add(p);
            }
        }
    }
}
