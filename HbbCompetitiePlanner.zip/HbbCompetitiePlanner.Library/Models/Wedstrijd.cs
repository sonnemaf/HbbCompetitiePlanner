﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Wedstrijd : ObservableObject {
       

        public Team Team1 { get; }

        public Team Team2 { get; }

        public Poul Poul { get; }

        public Wedstrijd(Team team1, Team team2, Poul poul) {
            this.Team1 = team1;
            this.Team2 = team2;
            this.Poul = poul;
        }

    }
}
