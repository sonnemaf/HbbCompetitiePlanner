﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Competitie : ObservableObject {

        public string Naam { get; set; }

        public List<Speelavond> Speelavonden { get; } = new List<Speelavond>();
        public List<Poul> Pouls { get; } = new List<Poul>();

    }
}
