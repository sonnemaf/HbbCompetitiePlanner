﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Speelavond : ObservableObject {

        public DateTime Datum { get; set; }
        public int AantalBanen { get; set; }

        public Speelavond() {

        }

    }
}
