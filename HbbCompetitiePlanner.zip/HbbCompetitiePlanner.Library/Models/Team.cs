﻿using ReflectionIT.Universal.Helpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace HbbCompetitiePlanner.Library.Models {

    public class Team : ObservableObject {

        public string Naam { get; set; }


    }
}
